# Mini App → webhook: событие открытия

Архив не содержит исходников самого Mini App, поэтому его фронтенд нельзя изменить автоматически. После открытия Mini App добавьте один вызов на стороне Mini App.

```html
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<script>
  const tg = window.Telegram.WebApp;
  tg.ready();

  fetch("/.netlify/functions/webhook", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "mini_app_opened",
      initData: tg.initData
    })
  }).catch(() => {
    // Открытие Mini App не должно блокировать интерфейс.
  });
</script>
```

Если Mini App и Netlify Function находятся на разных доменах, используйте полный URL webhook вместо относительного:

```js
fetch("https://YOUR-NETLIFY-SITE.netlify.app/.netlify/functions/webhook", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    action: "mini_app_opened",
    initData: window.Telegram.WebApp.initData
  })
});
```

Webhook проверяет подпись `Telegram.WebApp.initData` через `BOT_TOKEN`, поэтому передавать произвольный `tg_id` вместо подписанных данных нельзя.

Событие фиксируется только при первом открытии: повторные открытия не сбрасывают `mini_app_opened_at`. Это важно, чтобы таймеры 3/5/15/20 минут не начинались заново.

## Что происходит дальше

- `3 мин` — первое напоминание о незавершённой регистрации.
- `5 мин` — второе напоминание.
- `15 мин` — третье напоминание.
- `20 мин` — финальное напоминание.

Минутный scheduler проверяет не конкретную минуту на часах, а разницу между `NOW()` и `mini_app_opened_at`, поэтому открытие в `12:07:43` считается от `12:07:43`, а не от `12:08`.

Для каждого сообщения используется уникальный ключ доставки в БД. Повторный запуск scheduler или параллельный запуск не отправляет одно и то же сообщение повторно.
