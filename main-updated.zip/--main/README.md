# Telegram marathon bot — состояние и таймеры

## Что изменено

- Состояние пользователей перенесено в Netlify Database.
- `/start` сохраняет пользователя как `started`.
- Регистрация переводит пользователя в `registered`.
- Mini App отправляет подписанное Telegram `initData` событием `mini_app_opened`.
- `mini_app_opened_at` фиксируется один раз.
- Относительные напоминания после открытия Mini App: 3/5/15/20 минут.
- Незавершённый опрос отслеживается через `survey_step` и `survey_last_activity_at`.
- Для опроса предусмотрены напоминания через 15 и 60 минут после последнего шага.
- `bot_deliveries` обеспечивает идемпотентность отправок.
- `bot_updates` защищает обработку Telegram webhook update от повторной обработки.
- Существующая календарная серия сообщений сохранена; её получатели теперь берутся из Netlify Database.

## Database

Миграция: `netlify/database/migrations/0001_bot_state.sql`.

Netlify Database должен быть создан/подключён к сайту. Netlify автоматически применяет миграции при деплое.

## Environment

Обязательная переменная:

- `BOT_TOKEN` — токен Telegram-бота.

Netlify Database предоставляет подключение автоматически. Код использует `@netlify/database`.

## Webhook Mini App

См. `MINI_APP_INTEGRATION.md`.

Mini App должен вызывать:

`POST /.netlify/functions/webhook`

с JSON:

```json
{
  "action": "mini_app_opened",
  "initData": "<Telegram.WebApp.initData>"
}
```

`initData` проверяется на сервере, поэтому сервер определяет Telegram user id самостоятельно.

## Scheduler

`netlify.toml` сохраняет ежеминутный запуск:

```toml
[functions."scheduler"]
  schedule = "* * * * *"
```

Относительные таймеры не зависят от времени запуска cron: scheduler каждый раз сравнивает текущий момент с сохранённым `mini_app_opened_at`.

## Проверка

Перед деплоем выполнена синтаксическая проверка Node.js для:

- `netlify/functions/db.js`
- `netlify/functions/webhook.js`
- `netlify/functions/scheduler.js`
