const { getDatabase } = require("@netlify/database");

const db = getDatabase();

async function ensureSchema() {
  await db.sql`
    CREATE TABLE IF NOT EXISTS bot_users (
      tg_id BIGINT PRIMARY KEY,
      username TEXT,
      first_name TEXT,
      phone TEXT,
      status TEXT NOT NULL DEFAULT 'started',
      started_at TIMESTAMPTZ,
      mini_app_opened_at TIMESTAMPTZ,
      registered_at TIMESTAMPTZ,
      survey_step TEXT,
      survey_started_at TIMESTAMPTZ,
      survey_last_activity_at TIMESTAMPTZ,
      survey_completed_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await db.sql`
    CREATE TABLE IF NOT EXISTS bot_updates (
      update_id BIGINT PRIMARY KEY,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await db.sql`
    CREATE TABLE IF NOT EXISTS bot_deliveries (
      id BIGSERIAL PRIMARY KEY,
      tg_id BIGINT NOT NULL,
      delivery_key TEXT NOT NULL,
      sent_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (tg_id, delivery_key)
    )
  `;
  await db.sql`
    CREATE INDEX IF NOT EXISTS bot_updates_created_idx ON bot_updates(created_at)
  `;
  await db.sql`
    CREATE INDEX IF NOT EXISTS bot_users_status_idx ON bot_users(status)
  `;
  await db.sql`
    CREATE INDEX IF NOT EXISTS bot_users_mini_app_opened_idx ON bot_users(mini_app_opened_at)
  `;
  await db.sql`
    CREATE INDEX IF NOT EXISTS bot_users_survey_activity_idx ON bot_users(survey_last_activity_at)
  `;
}

async function upsertStartedUser({ tgId, username = "", firstName = "" }) {
  await db.sql`
    INSERT INTO bot_users (tg_id, username, first_name, status, started_at, updated_at)
    VALUES (${tgId}, ${username}, ${firstName}, 'started', NOW(), NOW())
    ON CONFLICT (tg_id) DO UPDATE SET
      username = COALESCE(NULLIF(EXCLUDED.username, ''), bot_users.username),
      first_name = COALESCE(NULLIF(EXCLUDED.first_name, ''), bot_users.first_name),
      started_at = COALESCE(bot_users.started_at, EXCLUDED.started_at),
      updated_at = NOW()
  `;
}

async function markMiniAppOpened({ tgId, username = "", firstName = "" }) {
  await db.sql`
    INSERT INTO bot_users (
      tg_id, username, first_name, status, started_at, mini_app_opened_at, updated_at
    )
    VALUES (${tgId}, ${username}, ${firstName}, 'started', NOW(), NOW(), NOW())
    ON CONFLICT (tg_id) DO UPDATE SET
      username = COALESCE(NULLIF(EXCLUDED.username, ''), bot_users.username),
      first_name = COALESCE(NULLIF(EXCLUDED.first_name, ''), bot_users.first_name),
      mini_app_opened_at = COALESCE(bot_users.mini_app_opened_at, EXCLUDED.mini_app_opened_at),
      updated_at = NOW()
  `;
}

async function markRegistered({ tgId, name = "", phone = "" }) {
  await db.sql`
    INSERT INTO bot_users (
      tg_id, first_name, phone, status, started_at, registered_at, updated_at
    )
    VALUES (${tgId}, ${name}, ${phone}, 'registered', NOW(), NOW(), NOW())
    ON CONFLICT (tg_id) DO UPDATE SET
      first_name = COALESCE(NULLIF(EXCLUDED.first_name, ''), bot_users.first_name),
      phone = COALESCE(NULLIF(EXCLUDED.phone, ''), bot_users.phone),
      status = 'registered',
      registered_at = NOW(),
      updated_at = NOW()
  `;
}

async function markSurveyStep(tgId, step) {
  const now = new Date();
  await db.sql`
    UPDATE bot_users
    SET survey_step = ${step},
        survey_started_at = COALESCE(survey_started_at, ${now}),
        survey_last_activity_at = ${now},
        updated_at = NOW()
    WHERE tg_id = ${tgId}
  `;
}

async function markSurveyCompleted(tgId) {
  await db.sql`
    UPDATE bot_users
    SET survey_step = 'completed',
        survey_completed_at = NOW(),
        survey_last_activity_at = NOW(),
        updated_at = NOW()
    WHERE tg_id = ${tgId}
  `;
}

async function getRegisteredUsers() {
  const rows = await db.sql`
    SELECT tg_id FROM bot_users WHERE status = 'registered'
  `;
  return rows.map(r => Number(r.tg_id));
}

async function getPendingMiniAppUsers() {
  const rows = await db.sql`
    SELECT tg_id, mini_app_opened_at
    FROM bot_users
    WHERE status <> 'registered'
      AND mini_app_opened_at IS NOT NULL
      AND mini_app_opened_at <= NOW() - INTERVAL '3 minutes'
  `;
  return rows.map(r => ({ tgId: Number(r.tg_id), openedAt: new Date(r.mini_app_opened_at) }));
}

async function getIncompleteSurveyUsers() {
  const rows = await db.sql`
    SELECT tg_id, survey_last_activity_at, survey_step
    FROM bot_users
    WHERE status = 'registered'
      AND survey_started_at IS NOT NULL
      AND survey_completed_at IS NULL
      AND survey_last_activity_at IS NOT NULL
      AND survey_last_activity_at <= NOW() - INTERVAL '15 minutes'
  `;
  return rows.map(r => ({
    tgId: Number(r.tg_id),
    lastActivityAt: new Date(r.survey_last_activity_at),
    step: r.survey_step
  }));
}

// Claiming is atomic because (tg_id, delivery_key) is unique.
// If the Telegram request fails, release the claim so the next scheduler tick can retry.
async function claimUpdate(updateId) {
  const rows = await db.sql`
    INSERT INTO bot_updates (update_id)
    VALUES (${updateId})
    ON CONFLICT (update_id) DO NOTHING
    RETURNING update_id
  `;
  return rows.length > 0;
}

async function claimDelivery(tgId, deliveryKey) {
  const rows = await db.sql`
    INSERT INTO bot_deliveries (tg_id, delivery_key)
    VALUES (${tgId}, ${deliveryKey})
    ON CONFLICT (tg_id, delivery_key) DO NOTHING
    RETURNING id
  `;
  return rows.length > 0;
}

async function completeDelivery(tgId, deliveryKey) {
  await db.sql`
    UPDATE bot_deliveries
    SET sent_at = NOW()
    WHERE tg_id = ${tgId} AND delivery_key = ${deliveryKey}
  `;
}

async function releaseDelivery(tgId, deliveryKey) {
  await db.sql`
    DELETE FROM bot_deliveries
    WHERE tg_id = ${tgId} AND delivery_key = ${deliveryKey} AND sent_at IS NULL
  `;
}

module.exports = {
  ensureSchema,
  upsertStartedUser,
  markMiniAppOpened,
  markRegistered,
  markSurveyStep,
  markSurveyCompleted,
  getRegisteredUsers,
  getPendingMiniAppUsers,
  getIncompleteSurveyUsers,
  claimUpdate,
  claimDelivery,
  completeDelivery,
  releaseDelivery
};
