CREATE TABLE IF NOT EXISTS bot_users (
  tg_id BIGINT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  phone TEXT,
  status TEXT NOT NULL DEFAULT 'started',
  started_at TIMESTAMPTZ,
  mini_app_opened_at TIMESTAMPTZ,
  registered_at TIMESTAMPTZ,
  survey_step TEXT,
  survey_started_at TIMESTAMPTZ,
  survey_last_activity_at TIMESTAMPTZ,
  survey_completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bot_updates (
  update_id BIGINT PRIMARY KEY,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bot_deliveries (
  id BIGSERIAL PRIMARY KEY,
  tg_id BIGINT NOT NULL,
  delivery_key TEXT NOT NULL,
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (tg_id, delivery_key)
);

CREATE INDEX IF NOT EXISTS bot_updates_created_idx ON bot_updates(created_at);
CREATE INDEX IF NOT EXISTS bot_users_status_idx ON bot_users(status);
CREATE INDEX IF NOT EXISTS bot_users_mini_app_opened_idx ON bot_users(mini_app_opened_at);
CREATE INDEX IF NOT EXISTS bot_users_survey_activity_idx ON bot_users(survey_last_activity_at);
